<title>Contacto | CDCcs™</title>

<?php
/* @var $this SiteController */
/* @var $model ContactForm */
/* @var $form CActiveForm */

$this->pageTitle=Yii::app()->name . ' - Contact Us';
$this->breadcrumbs=array(
	'Contacto',
);
?>

<?php

#class ContactController extends Controller
# {
#	public function actionCreate()
#	{
#		$model=new Contact;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

#		if(isset($_POST['Contact']))
#		{
#			$model->attributes=$_POST['Contact'];
#			if($model->save())
				
#					Yii::app()->user->setFlash("success","Mensaje enviado correctamente.");
#					$this->redirect(array('contact'));
#		}

#		$this->render('create',array('model'=>$model));
#	}
# }
?>

<h1>Contáctenos</h1>

<?php if(Yii::app()->user->hasFlash('contact')): ?>

<div class="flash-success">
	<?php echo Yii::app()->user->getFlash('contact'); ?>
</div>

<?php else: ?>

<p>
Si tiene preguntas de negocios u otras preguntas, rellene el siguiente formulario para ponerse en contacto con nosotros. Gracias.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'contact-form',
	'enableClientValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
	),
)); ?>

	<?php echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

<left><div class="span9"><img src="https://www.gordonramsayrestaurants.com/assets/Uploads/_resampled/CroppedFocusedImage63060050-50-Petrus-KT-Copy-2.jpg"></div></left>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

	<div>
		<?php echo $form->labelEx($model,'Nombre <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'name',array('placeholder'=>"Your name here",'title'=>"Your name here")); ?>
		<?php echo $form->error($model,'name'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Email <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'email',array('placeholder'=>"Your email here",'title'=>"Your email here")); ?>
		<?php echo $form->error($model,'email'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Asunto <span class="required">*</span>'); ?>
		<?php echo $form->textField($model,'subject',array('placeholder'=>"Your subject here",'title'=>"Your subject here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'subject'); ?>
	</div>

	<div>
		<?php echo $form->labelEx($model,'Mensaje <span class="required">*</span>'); ?>
		<?php echo $form->textArea($model,'body',array('placeholder'=>"Your body here",'title'=>"Your body here",'s'=>6, 'cols'=>50)); ?>
		<?php echo $form->error($model,'body'); ?>
	</div>

	<?php if(CCaptcha::checkRequirements()): ?>
	<div>
		<?php echo $form->labelEx($model,'verifyCode'); ?>
		<?php echo $form->error($model,'verifyCode'); ?>
		<div>
		<?php $this->widget('CCaptcha'); ?>

		<div class="hint"><p></p>Por favor, introduzca las letras como se muestran en la imagen de arriba.
		<p></p></div>

		<?php echo $form->textField($model,'verifyCode',array('placeholder'=>"Your captcha here",'title'=>"Your captcha here")); ?>
		</div>
		
	</div>
	<?php endif; ?>

	<div class=" buttons">
		<?php echo CHtml::submitButton('Enviar',array("class"=>"btn btn-primary btn-large")); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->

<?php endif; ?>