<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */


#If you want to reserve a table to celebrate your special event or simply to sit and have a drink from the comfort of our own establishment, please fill out the #following table reservations form. Thank you.
?>
<p>
Si desea agregar al inventario un producto en particular, para llevar un mejor control de la mercancía o simplemente para ahorrarse tiempo y dinero en el papeleo, y sin salir de la comodidad de su propio hogar, oficina o trabajo, por favor llene el siguiente formulario de inventario. Gracias.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'users-form',
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>true,
	),
)); ?>

	<?php echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

<left><div class="span9"><img src="http://i.imgur.com/RNAHwDp.gif"></div></left>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

	<div>
		Producto <span class="required">*</span>
		<?php echo $form->textField($model,'product',array('placeholder'=>"Your product here",'title'=>"Your product here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'product'); ?>
	</div>

	<div>
		Cantidad <span class="required">*</span>
		<?php echo $form->textField($model,'quantity',array('placeholder'=>"Your quantity here",'title'=>"Your quantity here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'quantity'); ?>
	</div>

	<div>
		Costo de entrada <span class="required">*</span>
		<?php echo $form->textField($model,'cost_of_entry',array('placeholder'=>"Your cost of entry here",'title'=>"Your cost of entry here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'cost_of_entry'); ?>
	</div>

	<div>
		Costo de salida <span class="required">*</span>
		<?php echo $form->textField($model,'cost_of_sale',array('placeholder'=>"Your cost of sale here",'title'=>"Your cost of sale here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'cost_of_sale'); ?>
	</div>

	<div>
		Cant min stock <span class="required">*</span>
		<?php echo $form->textField($model,'cant_min_stock',array('placeholder'=>"Your cant min stock here",'title'=>"Your cant min stock here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'cant_min_stock'); ?>
	</div>

<p></p>

	<div class="buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Inventariar' : 'Save', array("class"=>"btn btn-primary btn-large")); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->