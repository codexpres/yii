<title>Compras | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Compras',
);

$this->menu=array(
	array('label'=>'Agregar Compra', 'url'=>array('create')),
	array('label'=>'Gestionar Compras', 'url'=>array('admin')),
);
?>

<h1>Compras <?php echo CHtml::link("Exportar a Excel",array("index","excel"=>1),array("class"=>"btn"));?></h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
	'pager'=>array("htmlOptions"=>array("class"=>"pagination"))
)); ?>

