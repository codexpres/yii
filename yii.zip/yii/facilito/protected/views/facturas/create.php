<title>Compras | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Compras',
	'Agregar Compra',
);

$this->menu=array(
	array('label'=>'Lista de Compras', 'url'=>array('index')),
	array('label'=>'Gestionar Compras', 'url'=>array('admin')),
);
?>

<h1>Compras</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>