<title>Multimedia | CDCcs™</title>

<?php

class UsersController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}
}

$this->breadcrumbs=array(
	'Multimedia',
	'Producto Multimedia',
);

$this->menu=array(
	array('label'=>'Lista de Multimedia', 'url'=>array('index')),
);

#If you would like to order a home-cooked meal according to your location, to celebrate your special event, or just to sit and have coffee without leaving the #comfort of your own home or home, please fill out the following home delivery form. Thank you.
?>	

<h1>Producto multimedia</h1>

<p>
Si desea registrar un producto multimedia según su categoría, para celebrar su evento especial, o simplemente para sentarse y tomar un café sin salir de la comodidad de su hogar o casa, por favor llene el siguiente formulario de productos multimedia. Gracias.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'countries-form',
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>true,
	),
)); ?>

	<?php echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

	<left><div class="span9"><img src="http://i.imgur.com/W106dga.gif"></div></left>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

<div>
		Orígen <span class="required">*</span>
		<?php echo $form->textField($model,'origin',array('placeholder'=>"Your origin here",'title'=>"Your origin here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'origin'); ?>
	</div>

	<div>
		Descripción <span class="required">*</span>
		<?php echo $form->textField($model,'description',array('placeholder'=>"Your description here",'title'=>"Your description here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'description'); ?>
	</div>

	<div>
		Clase <span class="required">*</span>
		<?php echo $form->textField($model,'class',array('placeholder'=>"Your class here",'title'=>"Your class here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'class'); ?>
	</div>

	<div>
		Temporada
		<?php echo $form->textField($model,'season',array('placeholder'=>"Your season here",'title'=>"Your season here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'season'); ?>
	</div>

	<div>
		Físico
		<?php echo $form->textField($model,'physical',array('placeholder'=>"Your physical here",'title'=>"Your physical here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'physical'); ?>
	</div>

	<div>
		Digital
		<?php echo $form->textField($model,'digital',array('placeholder'=>"Your digital here",'title'=>"Your digital here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'digital'); ?>
	</div>

<p></p>

<?php echo CHtml::submitButton("Registrar",array("class"=>"btn btn-primary btn-large"));?>

</div>

<?php $this->endWidget();?>