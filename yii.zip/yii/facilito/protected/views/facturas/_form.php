<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */


#If you want to reserve a table to celebrate your special event or simply to sit and have a drink from the comfort of our own establishment, please fill out the #following table reservations form. Thank you.
?>
<p>
Si desea agregar una factura de un producto en particular, para llevar un mejor control de la mercancía o simplemente para ahorrarse tiempo y dinero en el papeleo, y sin salir de la comodidad de su propio hogar, oficina o trabajo, por favor llene el siguiente formulario de inventario. Gracias.
</p>

<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'users-form',
	'enableAjaxValidation'=>false,
	'enableClientValidation'=>true,
	'clientOptions'=>array(
	'validateOnSubmit'=>true,
	),
)); ?>

	<?php echo $form->errorSummary($model,null,null,array("class"=>"alert alert-error")); ?>

<left><div class="span9"><img src="http://i.imgur.com/IbQJ1mK.gif"></div></left>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

	<div>
		Fecha <span class="required">*</span>
		<?php $this->widget("zii.widgets.jui.CJuiDatePicker",array(
			"attribute"=>"date",
			"model"=>$model,
			"language"=>"es",
			"options"=>array(

			"minDate"=>"new Date()",
       		"maxDate"=>"new Date(9999, 12, 30)",

				"dateFormat"=>"yy-mm-dd"
				)	
		)); ?>
		<?php echo $form->error($model,'date'); ?>
	</div>

	<div>
		Proveedor <span class="required">*</span>
		<?php echo $form->textField($model,'provider',array('placeholder'=>"Your provider here",'title'=>"Your provider here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'provider'); ?>
	</div>

	<div>
		Producto <span class="required">*</span>
		<?php echo $form->textField($model,'product',array('placeholder'=>"Your product here",'title'=>"Your product here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'product'); ?>
	</div>

	<div>
		Costo <span class="required">*</span>
		<?php echo $form->textField($model,'cost',array('placeholder'=>"Your cost here",'title'=>"Your cost here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'cost'); ?>
	</div>

	<div>
		Cantidad <span class="required">*</span>
		<?php echo $form->textField($model,'quantity',array('placeholder'=>"Your quantity here",'title'=>"Your quantity here",'size'=>60,'maxlength'=>128)); ?>
		<?php echo $form->error($model,'quantity'); ?>
	</div>

<p></p>

	<div class="buttons">
		<?php echo CHtml::submitButton($model->isNewRecord ? 'Facturar' : 'Save', array("class"=>"btn btn-primary btn-large")); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- form -->