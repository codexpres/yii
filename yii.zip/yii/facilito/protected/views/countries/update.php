<title>Multimedia | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Multimedia',
	$model->id,
);
?>

<?php  
$this->menu=array(
	array('label'=>'Lista de Multimedia', 'url'=>array('index')),
	array('label'=>'Agregar Multimedia', 'url'=>array('create')),
	array('label'=>'Ver Multimedia', 'url'=>array("view","id"=>$model->id)),
	array('label'=>'Borrar Multimedia', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	);
?>

<h1>Actualizar la Multimedia #<?php echo $model->id?></h1>
<?php $form=$this->beginWidget("CActiveForm");?>

<br>
<b>Descripción</b><br>
<?php echo $form->textField($model,'description',array('placeholder'=>"Your description here",'title'=>"Your description here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'description'); ?>
<br>
<b>Clase</b><br>
<?php echo $form->textField($model,'class',array('placeholder'=>"Your class here",'title'=>"Your class here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'class'); ?>
<br>
<b>Orígen<br>
<?php echo $form->textField($model,'origin',array('placeholder'=>"Your origin here",'title'=>"Your origin here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'origin'); ?>
<br>
<b>Temporada</b><br>
<?php echo $form->textField($model,'season',array('placeholder'=>"Your season here",'title'=>"Your season here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'season'); ?>
<br>
<b>Físico</b><br>
<?php echo $form->textField($model,'physical',array('placeholder'=>"Your physical here",'title'=>"Your physical here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'physical'); ?>
<br>
<b>Digital</b><br>
<?php echo $form->textField($model,'digital',array('placeholder'=>"Your digital here",'title'=>"Your digital here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'digital'); ?>
<br>

<?php echo CHtml::submitButton("Actualizar",array("class"=>"btn btn-primary btn-large"));?>
<?php $this->endWidget();?>