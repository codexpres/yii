<title>Términos | CDCcs™</title>

<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'Términos de uso',
);
?>
<h1>Términos de Uso</h1>

<div class="thumbnail">

<small>
<p>
<ul><b>Términos de Uso de CDCcs™</b></ul>
</p>

<p style="text-align: justify;">
En el momento que usted, el usuario, nos facilita información de carácter personal a través de Cdcaracas.tk (en adelante, el “Sitio Web”) se respeta su intimidad y los derechos que le reconoce la normativa sobre protección de datos de carácter personal. Por ello, es importante que entienda qué información recabamos acerca de usted durante su visita y qué hacemos con dicha información la cual estará sujeta a la siguiente política sobre el tratamiento de datos personales.
<br>
Recomendamos leer detenidamente los siguientes puntos sobre nuestra Política de Privacidad; los que brindarán la total seguridad de que usted esta dentro de un sitio que protege su información e identidad.
</p>

<p style="text-align: justify;">
<b><li>Seguridad y protección de datos personales:</b> La seguridad de sus datos personales es una prioridad para este sitio web el cual ofrece seguridad total. Sin embargo, no nos responsabilizamos por las actividades de hackers o terceros que realizan acciones para dañar romper la seguridad que cada sitio brinda. Teniendo en consideración las características técnicas de transmisión de información a través de Internet, ningún sistema es 100% seguro o exento de ataques.</li>
</p>

<p style="text-align: justify;">
<b><li>Responsabilidad de opiniones:</b> Este sitio web solo se responsabiliza de las publicaciones aquí expuestas a manera de posts, mas no de los comentarios de éstas, ya que son realizados por terceros y/o visitantes del sitio.</li>
</p>

<p style="text-align: justify;">
<b><li>Su Privacidad:</b> Este sitio web respeta la privacidad de cada uno de sus visitantes. Toda información ingresada por el usuario a través de nuestro sitio web, será tratada con la mayor seguridad, y sólo será usada de acuerdo con las limitaciones establecidas en este documento.</li>
</p>

<p style="text-align: justify;">
<b><li>Obtención de información:</b> Este sitio web obtiene los datos personales suministrados directa, voluntaria y conscientemente por cada usuario. La información personal que solicitamos corresponde a datos básicos los cuales serán solicitados a través de los diferentes formularios que se publiquen aquí.</li>
</p>

<p style="text-align: justify;">
<b><li>Uso de la información:</b> Al suministrar datos personales, automáticamente estará autorizándonos para usar sus datos personales de conformidad con nuestra Política de Privacidad, lo cual comprende los siguientes eventos: a) para el propósito específico para el cual la ha suministrado; b) para incrementar nuestra oferta al mercado y hacer publicidad de productos que pueden ser de sumo interés para el usuario; incluyendo los llamados para confirmación de su información; c) para personalizar y mejorar nuestros productos y servicios, y d) para enviar e-mails con nuestros boletines, responder inquietudes o comentarios, y mantener informado a nuestros usuarios.</li>
</p>

<p style="text-align: justify;">
<b><li>Acceso a su información:</b> El sitio web tiene el compromiso permanente de presentar nuevas soluciones que mejoren el valor de sus productos y servicios; con el objeto de ofrecer oportunidades especiales de mercado, como incentivos, promociones y novedades actualizadas. CDCcs™ no comercializa, vende ni alquila su base de datos a otras empresas.</li>
</p>

<p style="text-align: justify;">
<b><li>Utilización de “Cookies”:</b> Este sitio web utiliza “cookies” y dirección IP sólo para obtener información general de sus usuarios y para proveerles de un sitio personalizado. Para esto, mantenemos un registro de: browser, sistema operativo usado por el usuario/visitante, nombre del dominio del Proveedor de Servicio de Internet. Adicionalmente mantenemos un registro del número total de visitantes el que nos permite realizar mejoras en nuestro sitio. Los “cookies” permiten entregar un contenido ajustado a los intereses y necesidades de nuestros usuarios/visitantes. También podrían usarse cookies de Terceros que estén presentes en este Weblog, como anunciantes o publicidad del mismo, con el único fin de proveer informaciones adicionales o reelevantes a la Navegación del Usuario en este Sitio Web.</li>
</p>

<p style="text-align: justify;">
<b><li>Revelación de información:</b> En ningún momento se utiliza o revela a terceros, la información individual de los usuarios así como los datos sobre las visitas, o la información que nos proporcionan: nombre, dirección, dirección de correo electrónico, número telefónico, etc.</li>
</p>

<p style="text-align: justify;">
<b><li>Modificaciones a nuestra Política de Privacidad:</b> El sitio web se reserva en forma exclusiva el derecho de modificar, rectificar, alterar, agregar o eliminar cualquier punto del presente escrito en cualquier momento y sin previo aviso.</li>
</p>

<ul><b>Estadísticas y otros sitios afines a CDCcs™</b></ul>

<p style="text-align: justify;">
Este sitio trabaja diferentes aplicaciones que evidentemente pueden hacer uso de Cookies almacenadas en su Equipo o utilizar algún script para el buen funcionamiento de este site.
<br>
Actualmente estas cookies sólo retiran información estadística, en ningún caso buscan recopilar información de carácter importante.
</p>
</small>

</div>

<u><h3><li><a href="http://www.cdcaracas.tk/yii/facilito/site/page.html?view=politica" target="_blank" class="info">Política de privacidad</a></li></h3></u>