<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">PRODUCTO</th>
		<th style="background-color: #555;color:#fff">CANTIDAD</th>
		<th style="background-color: #555;color:#fff">COSTO ENTRADA</th>
		<th style="background-color: #555;color:#fff">COSTO VENTA</th>
		<th style="background-color: #555;color:#fff">CANT MIN STOCK</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td><?php echo $data->id?></td>
		<td><?php echo $data->product?></td>
		<td><?php echo $data->quantity?></td>
		<td><?php echo $data->cost_of_entry?></td>
		<td><?php echo $data->cost_of_sale?></td>
		<td><?php echo $data->cant_min_stock?></td>
	</tr>
<?php endforeach;?>
</table>