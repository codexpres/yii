<?php

class CountriesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	public function accessRules()
	{
		return array(

			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create'),
				'users'=>array('@'),
			),
			array('allow', // allow demo user to perform 'index' and 'view' actions
			'actions'=>array('index','view'),
			'users'=>array('demo'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','create','update','delete','index','view','enabled'),
				'users'=>array('admin', 'Ander', 'Erick', 'Miriam', 'Laurence'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}



	public function actionIndex()
	{

		if(isset($_GET["excel"]))
		{
			$model=Countries::model()->findAll();
			$content=$this->renderPartial("excel",array("model"=>$model),true);
			Yii::app()->request->sendFile("Multimedia.xls",$content);
		}

		$countries=Countries::model()->findAll();
		$this->render("index",array("countries"=>$countries));
	}

	public function actionCreate()
	{
		$model=new Countries();
		if(isset($_POST["Countries"]))
		{
			$model->attributes=$_POST["Countries"];
			if($model->save())
			{
				Yii::app()->user->setFlash("success","Multimedia agregada correctamente.");
				$this->redirect(array("create"));
			}
		}
		$this->render("create",array("model"=>$model));
	}

	public function actionUpdate($id)
	{
		$model=Countries::model()->findByPk($id);
		if(isset($_POST["Countries"]))
		{
			$model->attributes=$_POST["Countries"];
			if($model->save())
			{
				Yii::app()->user->setFlash("success","Multimedia actualizada correctamente.");
				$this->redirect(array('view','id'=>$model->id));
			}
			else 
				Yii::app()->user->setFlash("error","Multimedia no se actualizó correctamente.");
		}
		$this->render("update",array("model"=>$model));
	}

	public function actionDelete($id)
	{
		$model=Countries::model()->deleteByPk($id);
		Yii::app()->user->setFlash("success","Multimedia eliminada correctamente.");
		$this->redirect(array("index"));
	}

	public function actionView($id)
	{
		$model=Countries::model()->findByPk($id);
		$this->render("view",array("model"=>$model));
	}

	public function actionEnabled($id)
	{
		$model=Countries::model()->findByPk($id);
		if($model->status==1)
			$model->status=0;
		else
			$model->status=1;
		$model->save();
		$this->redirect(array("index"));
	}
}  






















