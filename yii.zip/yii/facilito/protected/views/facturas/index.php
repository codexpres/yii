<title>Facturas | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Facturas',
);

$this->menu=array(
	array('label'=>'Agregar Factura', 'url'=>array('create')),
	array('label'=>'Gestionar Factura', 'url'=>array('admin')),
);
?>

<h1>Facturas <?php echo CHtml::link("Exportar a Excel",array("index","excel"=>1),array("class"=>"btn"));?></h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
	'pager'=>array("htmlOptions"=>array("class"=>"pagination"))
)); ?>

