<title>Facturas | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Facturas',
	$model->id,
);

$this->menu=array(
	array('label'=>'Lista de Facturas', 'url'=>array('index')),
	array('label'=>'Agregar Factura', 'url'=>array('create')),
	array('label'=>'Actualizar Factura', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Borrar Factura', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Gestionar Factura', 'url'=>array('admin')),
	'htmlOptions'=>array('label'=>'Imprimir', "url"=>"javascript:print()", array("class"=>"btn")),
);
?>

<h1>Ver la Factura #<?php echo $model->id; ?></h1>

<table class="table table-inverse table-bordered">
	<tr>
		<td><strong>ID</strong></td>
		<td><?php echo $model->id?></td>
	</tr>
	<tr>
		<td><strong>Proveedor</strong></td>
		<td><?php echo $model->provider?></td>	
	</tr>
	<tr>
		<td><strong>Producto</strong></td>
		<td><?php echo $model->product?></td>
	</tr>
	<tr>
		<td><strong>Fecha</strong></td>
		<td><?php echo $model->date?></td>	
	</tr>
	<tr>
		<td><strong>Costo</strong></td>
		<td><?php echo $model->cost?></td>
	</tr>
	<tr>
		<td><strong>Cantidad</strong></td>
		<td><?php echo $model->quantity?></td>
	</tr>
	
</table>
