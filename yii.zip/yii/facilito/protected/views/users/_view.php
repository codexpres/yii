<title>Inventario | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $data Users */
?>

<?php #foreach($users as $data):?>

<div class="media">
	<div class="media-body">
		<h3 class="media-heading">
			<?php echo CHtml::encode($data->getAttributeLabel('id')); ?>: <?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
			<small><b><?php echo CHtml::encode($data->product); ?></b></small> 
		</h3>
		<h6><b>CANTIDAD: <?php echo CHtml::encode($data->quantity); ?> | <?php echo CHtml::encode($data->cost_of_entry); ?> | <?php echo CHtml::encode($data->cost_of_sale); ?> | CANT MIN STOCK: <?php echo CHtml::encode($data->cant_min_stock); ?></b></h6>

		<p style="text-align: justify;">
		<u>Se recuerda al empleado que la cuenta de usuario que crea en el sistema debe cumplir con las siguientes condiciones y responsabilidades:</u>
		<li>La cuenta es de uso exclusivo del Empleado. Los datos de acceso son personales e intransferibles.</li>
		<li>La cuenta sólo debe ser utilizada por el Empleado, nunca por representantes, amigos ni otras personas. Todo lo que se realice con la cuenta es registrado en Bitácora y será únicamente responsabilidad del Empleado.</li>
		<li>Los datos proporcionados en el Perfil deben ser ciertos, estar completos y actualizados todos los campos.</li>
		Y recuerde, trate a los demás clientes como a usted le gustaría ser tratado.</p>

	</div>
</div>

<ul><small><?php echo CHtml::link("Ver",array("view","id"=>$data->id));?> | <?php echo CHtml::link("Actualizar",array("update","id"=>$data->id));?></small></ul>

<hr>

<?php #endforeach;?>