<?php

/**
 * UserIdentity represents the data needed to identity a user.
 * It contains the authentication method that checks if the provided
 * data can identity the user.
 */
class UserIdentity extends CUserIdentity
{
	private $_id;
	/**
	 * Authenticates a user.
	 * The example implementation makes sure if the username and password
	 * are both 'demo'.
	 * In practical applications, this should be changed to authenticate
	 * against some persistent user identity storage (e.g. database).
	 * @return boolean whether authentication succeeds.
	 */
	public function authenticate()
	{
		if($this->username==='admin' && $this->password==='admin123' or $this->username==='demo' && $this->password==='demo' 
			#or $this->username==='test1' && $this->password==='pass1' or $this->username==='test2' && $this->password==='pass2'
			or $this->username==='Ander' && $this->password==='pass2' or $this->username==='Erick' && $this->password==='pass3'
			or $this->username==='Miriam' && $this->password==='pass4' or $this->username==='Laurence' && $this->password==='pass5'
			)
			$this->errorCode=self::ERROR_NONE;
		else
			$this->errorCode=self::ERROR_PASSWORD_INVALID;
		return !$this->errorCode;
	}
}

?>