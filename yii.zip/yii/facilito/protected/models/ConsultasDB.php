<?php 

	/**
	* 
	*/
	class ConsultasDB {

		public $codigo_verificacion;
		
		function guardar_usuario($nombre,$email,$password)
		{
			$conexion = Yii::app()->db;

			$codigo_verificacion = $this->codigo_verificacion = sha1(rand(10000,99999));

			$consulta = "INSERT INTO users(username,email,password,codigo_verificacion)";
			$consulta .= " VALUES ";
			$consulta .= "('$nombre', '$email', '$password', '$codigo_verificacion')";

			$resultado = $conexion->createCommand($consulta)->execute();
		}
	}

 ?>