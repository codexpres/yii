<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">FECHA</th>
		<th style="background-color: #555;color:#fff">PROVEEDOR</th>
		<th style="background-color: #555;color:#fff">PRODUCTO</th>
		<th style="background-color: #555;color:#fff">CANTIDAD</th>
		<th style="background-color: #555;color:#fff">COSTO</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td><?php echo $data->id?></td>
		<td><?php echo $data->date?></td>
		<td><?php echo $data->provider?></td>
		<td><?php echo $data->product?></td>
		<td><?php echo $data->quantity?></td>
		<td><?php echo $data->cost?></td>
	</tr>
<?php endforeach;?>
</table>