<?php
return array (
  'template' => 'default',
  'connectionId' => 'db',
  'tablePrefix' => 'registro',
  'modelPath' => 'application.models',
  'baseClass' => 'CActiveRecord',
  'buildRelations' => '1',
);
