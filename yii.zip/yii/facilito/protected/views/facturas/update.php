<title>Factura | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Facturas',
	$model->id,
);

$this->menu=array(
	array('label'=>'Lista de Facturas', 'url'=>array('index')),
	array('label'=>'Agregar Factura', 'url'=>array('create')),
	array('label'=>'Ver Factura', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Borrar Factura', 'url'=>array('delete')),
	array('label'=>'Gestionar Factura', 'url'=>array('admin')),
);
?>

<h1>Actualizar la Factura #<?php echo $model->id; ?></h1>
<?php $form=$this->beginWidget("CActiveForm");?>

<br>
<b>Proveedor</b><br>
<?php echo $form->textField($model,'provider',array('placeholder'=>"Your provider here",'title'=>"Your provider here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'provider'); ?>
<br>
<b>Producto</b><br>
<?php echo $form->textField($model,'product',array('placeholder'=>"Your product here",'title'=>"Your product here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'product'); ?>
<br>
<b>Fecha<br>
<?php $this->widget("zii.widgets.jui.CJuiDatePicker",array(
			"attribute"=>"date",
			"model"=>$model,
			"language"=>"es",
			"options"=>array(

			#"minDate"=>"new Date()",
       		#"maxDate"=>"new Date(9999, 12, 30)",

				"dateFormat"=>"yy-mm-dd"
				)	
		)); ?>
<?php echo $form->error($model,'date'); ?>
<br>
<b>Costo</b><br>
<?php echo $form->textField($model,'cost',array('placeholder'=>"Your cost here",'title'=>"Your cost here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'cost'); ?>
<br>
<b>Cantidad</b><br>
<?php echo $form->textField($model,'quantity',array('placeholder'=>"Your quantity here",'title'=>"Your quantity here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'quantity'); ?>
<br>

<?php echo CHtml::submitButton("Actualizar",array("class"=>"btn btn-primary btn-large"));?>
<?php $this->endWidget();?>