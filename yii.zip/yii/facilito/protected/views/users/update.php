<title>Inventario | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Inventario',
	$model->id,
);

$this->menu=array(
	array('label'=>'Lista de Productos', 'url'=>array('index')),
	array('label'=>'Agregar Producto', 'url'=>array('create')),
	array('label'=>'Ver Producto', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Borrar Producto', 'url'=>array('delete')),
	array('label'=>'Gestionar Inventario', 'url'=>array('admin')),
);
?>

<h1>Actualizar el Producto #<?php echo $model->id; ?></h1>
<?php $form=$this->beginWidget("CActiveForm");?>

<br>
<b>Producto<br>
<?php echo $form->textField($model,'product',array('placeholder'=>"Your product here",'title'=>"Your product here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'product'); ?>
<br>
<b>Cantidad</b><br>
<?php echo $form->textField($model,'quantity',array('placeholder'=>"Your quantity here",'title'=>"Your quantity here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'quantity'); ?>
<br>
<b>Costo de entrada</b><br>
<?php echo $form->textField($model,'cost_of_entry',array('placeholder'=>"Your cost of entry here",'title'=>"Your cost of entry here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'cost_of_entry'); ?>
<br>
<b>Costo de salida</b><br>
<?php echo $form->textField($model,'cost_of_sale',array('placeholder'=>"Your cost of sale here",'title'=>"Your cost of sale here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'cost_of_sale'); ?>
<br>
<b>Cant min stock</b><br>
<?php echo $form->textField($model,'cant_min_stock',array('placeholder'=>"Your cant min stock here",'title'=>"Your cant min stock here",'size'=>60,'maxlength'=>128)); ?>
<?php echo $form->error($model,'cant_min_stock'); ?>
<br>

<?php echo CHtml::submitButton("Actualizar",array("class"=>"btn btn-primary btn-large"));?>
<?php $this->endWidget();?>