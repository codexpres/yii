<?php

/**
 * This is the model class for table "facturas".
 *
 * The followings are the available columns in table 'facturas':
 * @property integer $id
 * @property string $date
 * @property string $provider
 * @property string $product
 * @property integer $quantity
 * @property integer $cost
 */
class Facturas extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Facturas the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'facturas';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('date, provider, product, quantity, cost', 'required'),
			array('date, provider, product, quantity, cost', 'length', 'max'=>128),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, provider, product, quantity', 'safe', 'on'=>'search'),
					array('date', 'comprobar_fecha'),
					array('provider', 'comprobar_proveedor'),
					array('product', 'comprobar_producto'),
				);
			}

		public function comprobar_fecha($attributes, $params)
			{
				$conexion=Yii::app()->db;

				$consulta = "SELECT `date` FROM `facturas` WHERE ";
				$consulta .= "date='".$this->date."'";

				$resultado = $conexion->createCommand($consulta);
				$filas = $resultado->query();

				foreach ($filas as $fila) 
				{
					if ($this->date === $fila['date'])
					{
						$this->addError('date', 'Fecha ya está cargada');
						break;
					}
				}
			}

		public function comprobar_proveedor($attributes, $params)
			{
				$conexion=Yii::app()->db;

				$consulta = "SELECT `provider` FROM `facturas` WHERE ";
				$consulta .= "provider='".$this->provider."'";

				$resultado = $conexion->createCommand($consulta);
				$filas = $resultado->query();

				foreach ($filas as $fila) 
				{
					if ($this->provider === $fila['provider'])
					{
						$this->addError('provider', 'Proveedor ya está cargado');
						break;
					}
				}
			}

		public function comprobar_producto($attributes, $params)
			{
				$conexion=Yii::app()->db;

				$consulta = "SELECT `product` FROM `facturas` WHERE ";
				$consulta .= "product='".$this->product."'";

				$resultado = $conexion->createCommand($consulta);
				$filas = $resultado->query();

				foreach ($filas as $fila) 
				{
					if ($this->product === $fila['product'])
					{
						$this->addError('product', 'Producto ya está cargado');
						break;
					}
				}
			}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'date' => 'Date',
			'provider' => 'Provider',
			'product' => 'Product',
			'quantity' => 'Quantity',
			'cost' => 'Cost',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search()
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('date',$this->date,true);
		$criteria->compare('provider',$this->provider,true);
		$criteria->compare('product',$this->product,true);
		$criteria->compare('quantity',$this->quantity,true);
		$criteria->compare('cost',$this->cost,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}
}