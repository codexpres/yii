<title>Inventario | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Inventario',
	$model->id,
);

$this->menu=array(
	array('label'=>'Lista de Productos', 'url'=>array('index')),
	array('label'=>'Agregar Producto', 'url'=>array('create')),
	array('label'=>'Actualizar Producto', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Borrar Producto', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Gestionar Inventario', 'url'=>array('admin')),
	'htmlOptions'=>array('label'=>'Imprimir', "url"=>"javascript:print()", array("class"=>"btn")),
);
?>

<h1>Ver el Producto #<?php echo $model->id; ?></h1>

<table class="table table-inverse table-bordered">
	<tr>
		<td><strong>ID</strong></td>
		<td><?php echo $model->id?></td>
	</tr>
	<tr>
		<td><strong>Producto</strong></td>
		<td><?php echo $model->product?></td>	
	</tr>
	<tr>
		<td><strong>Cantidad</strong></td>
		<td><?php echo $model->quantity?></td>	
	</tr>
	<tr>
		<td><strong>Costo de entrada</strong></td>
		<td><?php echo $model->cost_of_entry?></td>
	</tr>
	<tr>
		<td><strong>Costo de salida</strong></td>
		<td><?php echo $model->cost_of_sale?></td>
	</tr>
	<tr>
		<td><strong>Cant min stock</strong></td>
		<td><?php echo $model->cant_min_stock?></td>
	</tr>
	
</table>
