<?php
/* @var $this UsersController */
/* @var $model Users */
/* @var $form CActiveForm */
?>

<div class="wide form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'action'=>Yii::app()->createUrl($this->route),
	'method'=>'get',
)); ?>

	<div>
		<?php echo $form->label($model,'id'); ?>
		<?php echo $form->textField($model,'id',array('placeholder'=>"Your id here")); ?>
	</div>

	<div>
		<?php echo $form->label($model,'product'); ?>
		<?php echo $form->textField($model,'product',array('placeholder'=>"Your product here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div>
		<?php echo $form->label($model,'quantity'); ?>
		<?php echo $form->textField($model,'quantity',array('placeholder'=>"Your quantity here",'size'=>60,'maxlength'=>128)); ?>
	</div>

	<div class="buttons">
		<?php echo CHtml::submitButton('Buscar',array("class"=>"btn btn-primary btn-large")); ?>
	</div>

<?php $this->endWidget(); ?>

</div><!-- search-form -->