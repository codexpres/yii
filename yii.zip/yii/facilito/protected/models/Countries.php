<?php
class Countries extends CActiveRecord
{
	public static function model($ClassName=__CLASS__)
	{
		return parent::model($ClassName);
	}

	public function tableName()
	{
		return "countries";
	}

	public function rules()
	{
		return array(
			array("origin, description, class", "required"),
			array('season, physical, digital', 'length', 'max'=>128),
		);
	}
	public function getSelectName()
	{
		return $this->name." ".$this->id." =)";
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'origin' => 'Origin',
			'description' => 'Description',
			'class' => 'Class',
			'season' => 'Season',
			'physical' => 'Physical',
			'digital' => 'Digital',
		);
	}
}