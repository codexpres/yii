<title>Facturas | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Facturas',
	'Agregar Factura',
);

$this->menu=array(
	array('label'=>'Lista de Facturas', 'url'=>array('index')),
	array('label'=>'Gestionar Facturas', 'url'=>array('admin')),
);
?>

<h1>Factura</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>