<?php

class ValidarRegistro extends CFormModel
{
		public $nombre;
		public $email;
		public $password;
		public $repetir_password;

		public function tableName()
	{
		return "users";
	}

		public function rules()
			{
				return array(
					array(
						'nombre, email, password, repetir_password',
						'required',
						'message'=>'Este campo es obligatorio',
						),
					array('nombre', 'comprobar_nombre'),
					array('email', 'comprobar_email'),
				);
			}

		public function comprobar_nombre($attributes, $params)
			{
				$conexion=Yii::app()->db;

				$consulta = "SELECT username FROM users WHERE ";
				$consulta .= "username='".$this->nombre."'";

				$resultado = $conexion->createCommand($consulta);
				$filas = $resultado->query();

				foreach ($filas as $fila) 
				{
					if ($this->nombre === $fila['username'])
					{
						$this->addError('nombre', 'Usuario no disponible');
						break;
					}
				}
			}

		public function comprobar_email($attributes, $params)
			{
				$conexion=Yii::app()->db;

				$consulta = "SELECT email FROM users WHERE ";
				$consulta .= "email='".$this->email."'";

				$resultado = $conexion->createCommand($consulta);
				$filas = $resultado->query();

				foreach ($filas as $fila) 
				{
					if ($this->email === $fila['email'])
					{
						$this->addError('email', 'Email no disponible');
						break;
					}
				}
			}

		public function getSelectName()
	{
		return $this->name." ".$this->id." =)";
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
		public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'email' => 'Email',
			'password' => 'Password',
			'repetir_password' => 'Repetir password',
		);
	}
}

?>