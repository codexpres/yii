<title>Acerca | CDCcs™</title>

<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - About';
$this->breadcrumbs=array(
	'Acerca de nosotros',
);
?>
<h1>Acerca de Nosotros</h1>

<p>
<ul><b>Acerca de CDCcs™</b></ul>
</p>

<h3><div class="span9"><img src="http://maresa.com/v2/wp-content/uploads/2012/06/DSC02948.jpg" align="left" width="682" height="384"></div>Ubicación</h3>
<p style="text-align: justify;">
A escasos 500 metros de la estación del metro La California, la empresa o local de contenido multimedia CDCcs™ está ubicado en la Avenida Principal de Macaracuay, en el Centro Comercial Macaracuay Xpress, entre la Danubio, al lado del Farmatodo. Cuenta con un amplio y variado catálogo donde usted podrá escoger la serie, vídeo musical, o vídeo fítness de su preferencia.<br>
<br>
Al llegar a la entrada del centro comercial, un amplio y seguro estacionamiento acoge a los clientes con unos grandes, modernos y seguros puestos para aparcar el coche. El suelo está cubierto con elegantes, cómodas y modernas piedras de mármol alrededor de las paredes. Acompañando el lugar, con distintos locales de comida, para aquellos osados que buscan tomarse algo fuera de lo común y comerse algo muy innovador y excéntrico, mientras esperan a ser atendidos y asesorados acerca de su futura próxima respectiva compra en nuestro local con televisión en alta definición, por el amable y gentil vendedor. En definitiva, una experiencia muy interesante e inolvidable, difícil de olvidar…
</p>

<ul><h3>Reseña histórica</h3></ul>
<p style="text-align: justify;">
En el 3 de febrero de 1980, el trigésimo cuarto día del año en el calendario gregoriano, nace el jefe de CDCcs™, Lawrence Aparicio. Venezolano, educado en G. Holmes Braddock High School (Miami), Lawrence Aparicio siempre tuvo como objetivo la idea o el sueño de cumplir una de sus metas: abrir su propio local de contenido multimedia.<br>
<br>
Pero no fue, sino hasta poco tiempo después, en el 14 de septiembre de 2016, cuando su vida dio un giro inesperado. Le sucedió lo que a muchos de nosotros, empresarios y venezolanos nos pasa algún día: Separarse de su familia, y dejarlo todo, su país, su hogar, para forjarse un nuevo destino, y tener lo que muchos de nosotros los venezolanos anhelamos con todo el alma, con todo el corazón: tener un futuro…<br>
<br>
Mas sin embargo, eso no lo detuvo. A pesar de todos los obstáculos que en su vida, en su trayecto para cumplir ese sueño consiguió, actualmente, el chef tiene 37 años, y es uno de los empresarios más jóvenes en adentrarse, trascender y progresar en este hermoso y variado mundo del contenido multimedia…<br>
<br>
Hoy por hoy, eso es CDCcs™, un local de contenido multimedia inspirado en eso, en el “CD” (compact disc o disco compacto), en la alta gama de variedad y calidad que los clientes o compradores pueden disfrutar en sus novedosos, creativos e innovadores contenidos multimedia. Un lugar donde el tiempo trasciende lentamente, donde se destacan las series y vídeos típicos del mundo del entretenimiento, donde amigos, extraños y familiares disfrutan en conjunto. Porque eso es lo que se busca, eso es lo que somos. Juntos, todos somos CDCcs™.
</p>

<ul><h3>Visión</h3></ul>
<p style="text-align: justify;">
Somos una empresa encargada de trascender las fronteras en el alto y variado mundo de la multimedia, creando contenidos con una alta gama en variedad y calidad, que puedan disfrutar y entretener a cualquiera de nuestros muchos distinguidos y variados clientes.
</p>

<ul><h3>Misión</h3></ul>
<p style="text-align: justify;">
Ser reconocidos como una empresa de la mayor gama y variedad de contenido multimedia en cuanto a calidad y variedad se refiere. Comprometidos con la calidad empresarial y los valores humanos que son los que forman a un gran ciudadano.
</p>