<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">PROVEEDOR</th>
		<th style="background-color: #555;color:#fff">PRODUCTO</th>
		<th style="background-color: #555;color:#fff">CANTIDAD</th>
		<th style="background-color: #555;color:#fff">FECHA</th>
		<th style="background-color: #555;color:#fff">COSTO</th>
		<th style="background-color: #555;color:#fff">PAGADO EN</th>
		<th style="background-color: #555;color:#fff">PAGADO EL</th>
		<th style="background-color: #555;color:#fff">COMPROBANTE O DEPOSITO</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td><?php echo $data->id?></td>
		<td><?php echo $data->provider?></td>
		<td><?php echo $data->product?></td>
		<td><?php echo $data->quantity?></td>
		<td><?php echo $data->date?></td>
		<td><?php echo $data->cost?></td>
		<td><?php echo $data->paid_in?></td>
		<td><?php echo $data->paid_on?></td>
		<td><?php echo $data->proof_or_deposit?></td>
	</tr>
<?php endforeach;?>
</table>