<title>Registro | CDCcs™</title>

<?php

$this->pageTitle = 'Formulario de registro';

$this->breadcrumbs = array('Registro');

?>

 <h1 class="form-signin-heading">Cree una cuenta gratis</h1>

<p>Por favor llene el siguiente formulario con sus credenciales de registro:</p>

<div class="form">
<?php 
$form=$this->beginWidget('CActiveForm', array(
	'method'=>'post',
	'action'=>Yii::app()->createUrl('site/registro'),
	'id'=>'form',
	'enableClientValidation'=>true,
	'enableAjaxValidation'=>true,
	'clientOptions'=>array(
		'validateOnSubmit'=>true,
		),

)); 
?>

<p class="note">Los campos con <span class="required">*</span> son obligatorios.</p>

  <div>
  	<?php 
  	echo $form->labelEx($model, 'nombre');
  	echo $form->textField($model, 'nombre',array('placeholder'=>"Your username here",'pattern'=>"/*[a-z0-9áéíóúàèìòùñ\_]+$/i",'required'=>"", 
		'title'=>"Your username here",'type'=>"text",'size'=>60,'maxlength'=>128));
  	echo $form->error($model, 'nombre');
  	 ?>
  </div>

  <div>
  	<?php 
  	echo $form->labelEx($model, 'email');
	echo $form->textField($model,'email',array('placeholder'=>"Your email address here",'pattern'=>"^[a-zA-Z0-9.!#$%&amp;'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$",'required'=>"", 
		'title'=>"nombre@ejemplo.com",'type'=>"text",'size'=>60,'maxlength'=>128));
  	echo $form->error($model, 'email');
  	 ?>
  </div>

  <div>
  	<?php 
  	echo $form->labelEx($model, 'password');
  	echo $form->passwordField($model, 'password',array('placeholder'=>"Your password here",#'pattern'=>"/^[a-z0-9]+$/i",
  		'required'=>"", 
		'title'=>"Your password here",'type'=>"password",'size'=>60,'maxlength'=>128));
  	echo $form->error($model, 'password');
  	 ?>
  </div>

  <div>
  	<?php 
  	echo $form->labelEx($model, 'repetir_password');
  	echo $form->passwordField($model, 'repetir_password',array('placeholder'=>"Your password here again",#'pattern'=>"/^[a-z0-9]+$/i",
  		'required'=>"",
  		'title'=>"Your password here again",'type'=>"password",'size'=>60,'maxlength'=>128));
  	echo $form->error($model, 'repetir_password');
  	 ?>
  </div>

<small>Al registrarse, usted está aceptando nuestros <u><a href="http://www.cdcaracas.tk/yii/facilito/site/page.html?view=terminos" target="_blank" class="info">Términos de uso</a></u> y nuestra <u><a href="http://www.cdcaracas.tk/yii/facilito/site/page.html?view=politica" target="_blank" class="info">Política de privacidad</a></u> del sitio.</small>

<p></p>

  <div>
  	<?php 
  	echo CHtml::submitButton("Registrarse", array('class'=>"btn btn-primary btn-large"));
  	 ?>
  </div>

<?php $this->endWidget(); ?>
</div><!-- form -->