<title>Inventario | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Maestros'=>array('maestros/create'),
	'Agregar Producto',
);

$this->menu=array(
	array('label'=>'Lista de Productos', 'url'=>array('index')),
	array('label'=>'Gestionar Inventario', 'url'=>array('admin')),
);
?>

<h1>Inventario</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>