<table>
	<tr>
		<th style="background-color: #555;color:#fff">ID</th>
		<th style="background-color: #555;color:#fff">ORIGEN</th>
		<th style="background-color: #555;color:#fff">DESCRIPCION</th>
		<th style="background-color: #555;color:#fff">CLASE</th>
		<th style="background-color: #555;color:#fff">TEMPORADA</th>
		<th style="background-color: #555;color:#fff">FISICO</th>
		<th style="background-color: #555;color:#fff">DIGITAL</th>
	</tr>
<?php foreach($model as $data):?>
	<tr>
		<td><?php echo $data->id?></td>
		<td><?php echo $data->origin?></td>
		<td><?php echo $data->description?></td>
		<td><?php echo $data->class?></td>
		<td><?php echo $data->season?></td>
		<td><?php echo $data->physical?></td>
		<td><?php echo $data->digital?></td>
	</tr>
<?php endforeach;?>
</table>