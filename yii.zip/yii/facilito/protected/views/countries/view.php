<title>Multimedia | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Multimedia',
	$model->id,
);
?>

<?php  
$this->menu=array(
	array('label'=>'Lista de Multimedia', 'url'=>array('index')),
	array('label'=>'Agregar Multimedia', 'url'=>array('create')),
	array('label'=>'Actualizar Multimedia', 'url'=>array("update","id"=>$model->id)),
	array('label'=>'Borrar Multimedia', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	'htmlOptions'=>array('label'=>'Imprimir', "url"=>"javascript:print()", array("class"=>"btn")),
	);
?>

<h1>Ver detalles del Multimedia #<?php echo $model->id; ?></h1> 

<table class="table table-inverse table-bordered">
	<tr>
		<td><strong>ID</strong></td>
		<td><?php echo $model->id?></td>
	</tr>
	<tr>
		<td><strong>Descripción</strong></td>
		<td><?php echo $model->description?></td>	
	</tr>
	<tr>
		<td><strong>Clase</strong></td>
		<td><?php echo $model->class?></td>
	</tr>
	<tr>
		<td><strong>Orígen</strong></td>
		<td><?php echo $model->origin?></td>	
	</tr>
	<tr>
		<td><strong>Temporada</strong></td>
		<td><?php echo $model->season?></td>
	</tr>
	<tr>
		<td><strong>Físico</strong></td>
		<td><?php echo $model->physical?></td>
	</tr>
	<tr>
		<td><strong>Digital</strong></td>
		<td><?php echo $model->digital?></td>
	</tr>
	
</table>