<title>Inventario | CDCcs™</title>

<?php
/* @var $this UsersController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Productos',
);

$this->menu=array(
	array('label'=>'Agregar Producto', 'url'=>array('create')),
	array('label'=>'Gestionar Inventario', 'url'=>array('admin')),
);
?>

<h1>Productos <?php echo CHtml::link("Exportar a Excel",array("index","excel"=>1),array("class"=>"btn"));?></h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
	'pager'=>array("htmlOptions"=>array("class"=>"pagination"))
)); ?>

